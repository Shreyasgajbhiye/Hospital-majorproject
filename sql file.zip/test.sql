-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2023 at 02:05 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`id`) VALUES
('rv'),
('RV001'),
('rev'),
('jj');

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `gen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`gen`) VALUES
('Male'),
('Female'),
('Other');

-- --------------------------------------------------------

--
-- Table structure for table `med`
--

CREATE TABLE `med` (
  `id` int(11) NOT NULL,
  `med_name` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `med`
--

INSERT INTO `med` (`id`, `med_name`, `quantity`) VALUES
(1, 'Dolo ', 46),
(2, 'Vicks', 62),
(3, 'dopa', 88),
(4, 'disprin', 178),
(5, 'dysire', 138),
(6, 'Paradox', 88),
(7, 'Propa', 118),
(8, 'Zandubam', 108);

-- --------------------------------------------------------

--
-- Table structure for table `meds`
--

CREATE TABLE `meds` (
  `id` int(11) NOT NULL,
  `med_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `name`, `age`, `gender`) VALUES
(1, 'Shreyash', 17, 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `opd`
--

CREATE TABLE `opd` (
  `sr_no` int(11) NOT NULL,
  `date` varchar(20) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL,
  `p_no` int(11) DEFAULT NULL,
  `med` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opd`
--

INSERT INTO `opd` (`sr_no`, `date`, `p_id`, `p_no`, `med`, `quantity`) VALUES
(1, '2023-02-02', 1, 1, 'Vicks', 10),
(2, '2023-02-09', 1, 1, 'disprin', 17),
(3, '2023-02-09', 2, 3, 'Propa', 11),
(4, '2023-02-01', 2, 3, 'Paradox', 12),
(5, '2023-02-01', 1, 1, 'Dolo', 208),
(6, '2023-02-04', 2, 2, 'Dolo', 208),
(7, '2023-02-04', 2, 2, 'Dolo', 158),
(8, '2023-02-03', 1, 4, 'disprin', 10),
(9, '2023-02-04', 2, 1, 'Vicks', 10),
(10, '2023-02-03', 2, 2, 'Vicks', 2),
(11, '2023-02-10', 1, 1, 'dysire', 2),
(12, '2023-02-11', 1, 1, 'Dolo', 2),
(13, '2023-02-24', 2, 65, 'Vicks', 6),
(14, '2023-03-01', 2, 22, 'Vicks', 50),
(15, '2023-03-01', 2, 22, 'Dolo', 50);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `op` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`op`) VALUES
('Medicines'),
('Stationary'),
('Disposable'),
('Etc');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `id` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` varchar(11) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`id`, `name`, `age`, `gender`) VALUES
('abc1', 'abc1', 'abc1', 'abc1'),
('abc1', 'Shreyash', '17', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`) VALUES
(1, 'Shreyash'),
(2, 'soham');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `otp` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `otp`) VALUES
(1, 'vishalphpyt@gmail.com', ''),
(2, 'shreyashgajbhiye90@gmail.com', '}V2hO@'),
(3, 'cparaskar2004@gmail.com', '3bf^Be'),
(4, 'sgajbhiye1410gmail.com', ''),
(5, 'shreyavborode@gmail.com', 'nMDIEU'),
(6, 'srushtideshmukh2315@gmail.com', ''),
(7, 'abhayawachar2005@gmail.com', ''),
(8, 'dhokedivya85@gmail.com', ''),
(9, 'sakshigaykawad24@gmail.com', ''),
(10, 'nikitagore1112@gmail.com', ''),
(11, 'nikitagore1112@gmail.com', ''),
(12, 'kshitijhadke26@gmail.com', ''),
(13, 'aradhanahingne@gmail.com', ''),
(14, 'hirulkarkalyani@gmail.com', ''),
(15, ' shreyashingle2004@gmail.com', ''),
(16, 'atharvaisokar@gmail.com', ''),
(17, 'vedikajoshi18@gmail.com', ''),
(19, 'anjalikaware404@gmail.com', ''),
(20, 'mohangawande93@gmail.com', ''),
(21, 'pranavnanne@gmail.com', ''),
(22, 'rutujanikam@gmail.com', ''),
(23, ' nimbolkaryogita@gmail.com', ''),
(24, ' shreyanarendrapande@gmail.com', ''),
(25, ' deveshpatilamt205@gmail.com', ''),
(26, 'patilnikita2345@gmail.insamikshap803@gmail.com', ''),
(27, 'cmomkarshelke@gmail.com', ''),
(28, 'shravanishinganwadikar@gmail.com', ''),
(29, 'samirsontakke2005@gmail.com', ''),
(30, ' sushanttelgote4@gmail.com', ''),
(31, 'toshniwalrutuja7@gmail.com', ''),
(32, 'vishakha.tayade19@gmail.com', ''),
(33, 'tanviwaghmare49@gmail.com', ''),
(34, 'shrutiwawage09@gmail.com', ''),
(35, 'aachalzape7@gmail.com', ''),
(36, 'Gauravawagan56@gmail.com', ''),
(37, 'ombokade07@gmail.com', ''),
(38, 'mgiri7573@gmail.com', ''),
(39, 'munawwarmiyan0773@gmail.com', ''),
(40, 'vipultayde14@gmail.com', ''),
(41, 'purvakale29@gmail.com', 'FWXg08'),
(80, 'aadityathakare124@gmail.com', 'iTtP<7');

-- --------------------------------------------------------

--
-- Table structure for table `village`
--

CREATE TABLE `village` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `village`
--

INSERT INTO `village` (`id`, `name`) VALUES
(1, 'Revsa'),
(2, 'Tadvel'),
(3, 'Chandurbazar'),
(4, 'Akola'),
(5, 'xyz');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `med`
--
ALTER TABLE `med`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `opd`
--
ALTER TABLE `opd`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `village`
--
ALTER TABLE `village`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `med`
--
ALTER TABLE `med`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `opd`
--
ALTER TABLE `opd`
  MODIFY `sr_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `village`
--
ALTER TABLE `village`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
