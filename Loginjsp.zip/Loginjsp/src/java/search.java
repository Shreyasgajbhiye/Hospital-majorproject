/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.sql.*;
public class search {
    public static void main(String [] args){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            

            String sql = "select  from jdbc";

            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs=stmt.executeQuery();
            while(rs.last()){
                System.out.println(""+rs.getString(1)+""+rs.getInt(2)+""+rs.getInt(3));
                break;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}

